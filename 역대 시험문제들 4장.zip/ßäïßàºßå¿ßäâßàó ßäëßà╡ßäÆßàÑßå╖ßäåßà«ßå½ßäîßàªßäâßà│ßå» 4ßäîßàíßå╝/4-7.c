void swap(struct node *s, struct node *t){
    struct node *temp;
    temp = t->link;
    t->link = temp->link;
    temp->link = t->link->link
    t->link->link = temp;
}

void swap(struct node *s, struct node *t){
    struct node *temp1, *temp2;
    temp1 = t->next;
    temp2 = temp1->next;
    temp1->next = temp2->next;
    temp2->next = temp1;
    t->next = temp2;
}

