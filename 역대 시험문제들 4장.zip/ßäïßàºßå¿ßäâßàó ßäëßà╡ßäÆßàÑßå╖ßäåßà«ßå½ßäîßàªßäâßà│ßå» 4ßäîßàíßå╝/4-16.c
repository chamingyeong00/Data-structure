struct node *merge(struct node *list1, struct node *list2){

}